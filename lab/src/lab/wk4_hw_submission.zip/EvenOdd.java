package lab;

public class EvenOdd {

	public static void main(String[] args) {
		// 
		int num = Integer.parseInt(args[0]);
		if (num % 2 != 0){
			System.out.println("what and odd number");
		
		}
		else {
			System.out.println("ok, we're even!");
		}

	}

}
